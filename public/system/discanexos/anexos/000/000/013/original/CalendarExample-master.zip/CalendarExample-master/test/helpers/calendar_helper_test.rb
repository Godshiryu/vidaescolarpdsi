require 'test_helper'

class CalendarHelperTest < ActionView::TestCase
end
