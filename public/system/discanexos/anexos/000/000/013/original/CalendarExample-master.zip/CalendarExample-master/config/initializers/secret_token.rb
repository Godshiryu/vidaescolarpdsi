# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
CalendarExample::Application.config.secret_key_base = 'd747229c6109a8af425686f0431f256e0ce7d3f6e057f45368963f6bf2a191f9439590d85d803e79d4fb16484d0f5203f16432d54f47fff52f1de553b41c3d0b'
